let express = require("express");
let app = express();
let path = require("path");
let http = require("http").Server(app);
let io = require("socket.io")(http);
let mongoose = require("mongoose");

app.use(express.static(path.join(__dirname,'/')));
mongoose.pluralize(null); 
let url = "mongodb://localhost:27017/chatlog";

    mongoose.connect(url).
    then(res=>console.log("connected")).
    catch(err=>console.log(err))

//    let db = mongoose.connection;
    let allChats = mongoose.Schema({
        
        name: String,
        msg : String
        
    })

// using schema we have to create the model 
    //1st parameter collection name and 2nd parameter schema reference
    // mongoose intenrally create collection name in lower case 
    // with post fix s.
    let chatModel = mongoose.model("ChatBot",allChats);

    app.get("/",(request,response)=> {
        response.sendFile(__dirname+"\\index.html");


    })  


   io.on("connection", (socket)=>{
    socket.on("message",(mun)=> {
            let questions = [
                 'Hello there',
                 'How are you',
                 'What\'s up',
                 'What can i do for you?',
                 'Are you having a good day so far?',
                 'Check out this new book',
                 'Do you listen to music?'
             ];
         const random = Math.floor(Math.random() * questions.length);
         socket.emit("obj1", questions[random]);
         chatModel.insertMany(mun, (err, result)=>{
            if (!err){
                  console.log("Submitted");
            }else{
                console.log(err);
            }
         })
         console.log(mun);
        });
      socket.emit("obj1", "Hey Guys")
})
http.listen(9090, ()=>console.log("Server running on 9090"))