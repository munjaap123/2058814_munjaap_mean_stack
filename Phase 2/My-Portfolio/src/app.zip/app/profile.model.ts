export class profile {
    constructor(public fname:string, public lname:string, public usern: any, public passw: any){}
}