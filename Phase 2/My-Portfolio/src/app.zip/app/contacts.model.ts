export class contacts{

    constructor(public cname: string, public phone: number){}
}
